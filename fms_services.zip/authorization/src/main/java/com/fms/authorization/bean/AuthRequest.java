/**
 * 
 */
package com.fms.authorization.bean;

import lombok.Data;

/**
 * @author Kesavalu
 *
 */
@Data
public class AuthRequest {

	private String username;
	private String password;
}
