package com.fms.authorization;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AuthorizationApplicationTests {

	@Test
	void contextLoads() {
	}

}
