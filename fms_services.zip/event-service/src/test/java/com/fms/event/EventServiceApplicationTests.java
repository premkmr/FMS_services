package com.fms.event;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class EventServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
