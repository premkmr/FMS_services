/**
 * 
 */
package com.fms.event.util;

/**
 * @author Kesavalu
 *
 */
public class EventConstants {

	private static final String EVENT_SUMMARY_JOB="eventSummaryJob";
	private static final String EVENT_PARTICIPANT_JOB="eventParticipantJob";
	
}
