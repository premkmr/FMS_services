package com.fms.event.jackson;
public class View {
	public interface Summary {}
	public interface SummaryWithDetail extends Summary{}
}