/**
 * 
 */
package com.fms.event.util;

/**
 * @author Kesavalu
 *
 */
public class Constants {

	public static final int ACTIVE = 1;
	public static final int INACTIVE = 0;
	public static final int DELETED = 1;
	public static final int PRESENT = 0;
}
